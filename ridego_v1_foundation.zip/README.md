# RideGo — Ride Booking Platform
Version: 1.0 foundation

Locked architecture:
- Customer App: Flutter
- Driver App: Flutter
- Backend API: Node.js + TypeScript + Express
- Database: PostgreSQL
- Real-time: Socket.IO
- Admin Panel: React + TypeScript (next phase)
- Maps/Payments: integration interfaces prepared; provider keys added later

## Repository
- apps/customer_app
- apps/driver_app
- apps/admin_panel
- services/api
- database
- docs

## Important
Do not edit database/API contracts manually during setup. New features will be added by versioned migrations and endpoints.
