# RideGo API Contract V1

Base URL: `/api/v1`

## Authentication
POST /auth/send-otp
POST /auth/verify-otp

## Customer
GET /customer/profile
POST /rides/estimate
POST /rides
GET /rides
GET /rides/:id
POST /rides/:id/cancel
POST /rides/:id/rating

## Driver
GET /driver/profile
POST /driver/online
POST /driver/location
GET /driver/rides/current
POST /driver/rides/:id/accept
POST /driver/rides/:id/arrived
POST /driver/rides/:id/start
POST /driver/rides/:id/complete
GET /driver/earnings

## Admin
GET /admin/dashboard
GET /admin/drivers
POST /admin/drivers/:id/approve
POST /admin/drivers/:id/reject
GET /admin/customers
GET /admin/rides
GET /admin/payments
GET /admin/reports

These routes are the V1 contract. New functionality should use additive endpoints or a versioned `/api/v2`.
