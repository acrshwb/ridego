import express from "express";
import cors from "cors";
import http from "http";
import { Server } from "socket.io";
import { checkDatabase } from "./db";

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: { origin: "*", methods: ["GET", "POST"] },
});

app.use(cors());
app.use(express.json());

app.get("/health", async (_req, res) => {
  try {
    const db = await checkDatabase();
    res.json({
      success: true,
      service: "ridego-api",
      database: "connected",
      time: db.now,
    });
  } catch {
    res.status(503).json({
      success: false,
      service: "ridego-api",
      database: "disconnected",
    });
  }
});

io.on("connection", (socket) => {
  socket.emit("connected", { socketId: socket.id });
});

const port = Number(process.env.PORT ?? 4000);

server.listen(port, () => {
  console.log(`RideGo API running on http://localhost:${port}`);
});
